/*
 * File: HPC_SinglePedalDrive_private.h
 *
 * Code generated for Simulink model 'HPC_SinglePedalDrive'.
 *
 * Model version                  : 13.66
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Tue Dec  3 14:37:48 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-A
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_HPC_SinglePedalDrive_private_h_
#define RTW_HEADER_HPC_SinglePedalDrive_private_h_
#include "rtwtypes.h"
#include "HPC_SinglePedalDrive_types.h"

/* Includes for objects with custom storage classes */
#include "App_HPC_Get_Set.h"
#endif                          /* RTW_HEADER_HPC_SinglePedalDrive_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
